
# GitHub Push 방법 (2분)

## 방법 1: Git 명령어 (권장)

# 1. 기존 클론이 있으면
cd NSW-Question-Bank
git pull origin main

# 2. 새로 받은 push 폴더 파일 덮어쓰기
# 다운로드한 github_push_v3 폴더의 모든 파일을 기존 NSW-Question-Bank 폴더에 덮어쓰기

# 3. 푸시
git add .
git commit -m "feat: v3 구현 - Stage 200문항 확장 + 학생 진단 + HSC Band 6 분석"
git push origin main

## 방법 2: GitHub 웹사이트에서 직접 업로드

1. https://github.com/michaeldschoo/NSW-Question-Bank 접속
2. Add file > Upload files 클릭
3. github_push_v3 폴더 안의 모든 파일 드래그 앤 드롭
4. Commit message: "feat: v3 구현 - Stage 200문항 확장 + 학생 진단 + HSC Band 6 분석"
5. Commit changes 클릭

## 무엇이 바뀌나?

- index.html이 v3로 교체됨 (4개 탭: 문제은행 / 200문항 확장 / 학생 진단 / HSC Band 6)
- README.md가 완성본으로 교체됨
- tools/ 3개 스크립트 + data/ 포함

## Private 전환 권장

경쟁 학원 방지하려면:
GitHub Repo > Settings > Danger Zone > Change visibility > Private

그 후 학원 선생님 초대:
Settings > Collaborators > Add people
